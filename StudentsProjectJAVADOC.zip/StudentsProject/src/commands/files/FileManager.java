package commands.files;

import interfaces.MenuItem;
import interfaces.Student;
import specialities.kst.KST;
import specialities.sit.SIT;
import student.StudentRepository;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Abstract class for managing file operations related to XML files.
 */
public abstract class FileManager implements MenuItem {

    private static File file;

    /**
     * Creates a new XML file with the given file name.
     *
     * @param fileName The name of the file to be created.
     */
    public static void createNewFile(String fileName) {
        if (!file.exists()) {
            try {
                file = new File(fileName);
                System.out.println("Creating file " + fileName + "..");
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else System.out.println("You need to close the currently opened file!");
    }

    /**
     * Opens an existing XML file or creates a new one if it doesn't exist.
     *
     * @param fileName The name of the file to be opened.
     * @return True if the file is successfully opened or created, false otherwise.
     */
    public static boolean openFile(String fileName) {
        if (file == null) {
            if (!fileName.contains(".xml")) {
                fileName += ".xml";
            }
            file = new File(fileName);
            if (!file.exists()) {
                createNewFile(fileName);
            }
            DataHandler.loadData();
            return true;
        }
        return false;
    }

    /**
     * Closes the currently opened file.
     *
     * @return True if the file is successfully closed, false otherwise.
     */
    public static boolean closeFile() {
        if (file == null) {
            return false;
        }
        file = null;
        return true;
    }

    /**
     * Saves the data to the currently opened file.
     */
    public static void save() {
        if (file != null) {
            try {
                FileWriter writer = new FileWriter(getFile());
                writer.write(DataHandler.saveData());
                writer.close();
                System.out.println("Data successfully saved!");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else System.out.println("There is no opened file to save!");
    }

    /**
     * Retrieves the currently opened file.
     *
     * @return The currently opened file.
     */
    public static File getFile() {
        return file;
    }
}
