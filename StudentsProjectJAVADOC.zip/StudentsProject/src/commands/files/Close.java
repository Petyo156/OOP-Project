package commands.files;

import interfaces.Student;
import specialities.kst.KST;
import specialities.sit.SIT;
import student.StudentRepository;

import java.util.List;

/**
 * Command for closing the currently opened file and clearing all student repositories.
 */
public class Close extends FileManager {
    @Override
    public void execute() {

    }

    /**
     * Closes the currently opened file and clears all student repositories.
     *
     * @param command The command string.
     */
    @Override
    public void execute(String command) {
        clearRepository(SIT.studentRepository1);
        clearRepository(SIT.studentRepository2);
        clearRepository(SIT.studentRepository3);
        clearRepository(SIT.studentRepository4);

        clearRepository(KST.studentRepository1);
        clearRepository(KST.studentRepository2);
        clearRepository(KST.studentRepository3);
        clearRepository(KST.studentRepository4);
        List<String> args = List.of(command.split(" "));
        if (args.size() == 1) {
            if (FileManager.closeFile()) {
                System.out.println("Current file successfully closed!");
            } else {
                System.out.println("No opened file..");
            }
        } else System.out.println("This command requires no arguments!");
    }

    /**
     * Clears a student repository.
     *
     * @param studentRepository The student repository to be cleared.
     */
    private static void clearRepository(StudentRepository studentRepository) {
        for (Student s : studentRepository.getCollection().stream().toList()) {
            studentRepository.remove(s);
        }
    }
}
