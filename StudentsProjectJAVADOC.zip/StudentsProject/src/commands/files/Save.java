package commands.files;

import java.util.List;

/**
 *  Saves the currently opened file
 */
public class Save extends FileManager {
    @Override
    public void execute() {

    }

    /**
     * Saves the currently opened file
     * @param command not used in this method.
     */
    @Override
    public void execute(String command) {
        List<String> args = List.of(command.split(" "));
        if (args.size() == 1) {
            FileManager.save();
        } else System.out.println("This command does not require any arguments!");
    }
}
