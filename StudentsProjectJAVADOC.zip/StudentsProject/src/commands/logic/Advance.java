package commands.logic;

import interfaces.Student;
import specialities.Course;
import specialities.kst.FourthCourse;
import specialities.kst.KST;
import specialities.kst.SecondCourse;
import specialities.kst.ThirdCourse;
import specialities.sit.SIT;
import student.StudentImpl;
import student.StudentRepository;
import student.discipline.Discipline;
import student.implementation.Status;

import static specialities.kst.FourthCourse.KST_DISCIPLINES_4;
import static specialities.kst.SecondCourse.KST_DISCIPLINES_2;
import static specialities.kst.ThirdCourse.KST_DISCIPLINES_3;
import static specialities.sit.FirstCourse.SIT_DISCIPLINES_1;
import static specialities.sit.FourthCourse.SIT_DISCIPLINES_4;
import static specialities.sit.SecondCourse.SIT_DISCIPLINES_2;
import static specialities.sit.ThirdCourse.SIT_DISCIPLINES_3;

/**
 * Command class for advancing a student to the next course in their speciality.
 */
public class Advance extends CommandsManager {
    /**
     * Executes the command to advance a student to the next course in their speciality.
     * @param command The command string containing the student's ID.
     */
    @Override
    public void execute(String command) {
        // Split the command string into an array
        String[] arr = command.split(" ");
        // Check if the command contains the required arguments
        if (arr.length == 1) {
            System.out.println("Enter a valid number of arguments!");
            return;
        }

        // Extract the student's ID from the command
        String fn = arr[1];

        // Check if the student is interrupted or graduated
        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }
        if (isGraduated(fn)) {
            System.out.println("Student " + fn + " is graduated.");
            return;
        }

        // Check if the student exists
        if(null == findByFakNum(fn)){
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        // Check if the student is already in the last course
        if(findByFakNum(fn).getCourse().getClass().getSimpleName().equals("FourthCourse")){
            System.out.println("Student is in the last course.");
            return;
        }

        // Advance the student in their speciality
        boolean isFound = advanceStudentInSpeciality(SIT.studentRepository1, SIT.studentRepository2, fn);
        isFound = isFound || advanceStudentInSpeciality(SIT.studentRepository2, SIT.studentRepository3, fn);
        isFound = isFound || advanceStudentInSpeciality(SIT.studentRepository3, SIT.studentRepository4, fn);

        isFound = isFound || advanceStudentInSpeciality(KST.studentRepository1, KST.studentRepository2, fn);
        isFound = isFound || advanceStudentInSpeciality(KST.studentRepository2, KST.studentRepository3, fn);
        isFound = isFound || advanceStudentInSpeciality(KST.studentRepository3, KST.studentRepository4, fn);
    }

    /**
     * Advances the student to the next course in their speciality.
     * Determines the course for the specified repository
     * Sets the disciplines for the student based on the specified course.
     * @param from The repository from which to advance the student.
     * @param to The repository to which to advance the student.
     * @param fn The student's FN.
     * @return True if the student was successfully advanced, false otherwise.
     */
    private boolean advanceStudentInSpeciality(StudentRepository from, StudentRepository to, String fn) {
        Student student = from.findByFakNum(fn);
        if (student != null) {
            //Removes the student from the current repository and adds him to the next one.
            from.remove(student);
            to.add(student);

            //Determines the course and sets the disciplines of the student based on the course.
            Course course = null;
            if (to.equals(SIT.studentRepository2)) {
                course = new specialities.sit.SecondCourse();
                for (Discipline d : SIT_DISCIPLINES_2) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(SIT.studentRepository3)) {
                course = new specialities.sit.ThirdCourse();
                for (Discipline d : SIT_DISCIPLINES_3) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(SIT.studentRepository4)) {
                course = new specialities.sit.FourthCourse();
                for (Discipline d : SIT_DISCIPLINES_4) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(KST.studentRepository2)) {
                course = new specialities.kst.SecondCourse();
                for (Discipline d : KST_DISCIPLINES_2) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(KST.studentRepository3)) {
                course = new specialities.kst.ThirdCourse();
                for (Discipline d : KST_DISCIPLINES_3) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(KST.studentRepository4)) {
                course = new specialities.kst.FourthCourse();
                for (Discipline d : KST_DISCIPLINES_4) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            }

            if (course != null) {
                student.setCourse(course);
                System.out.println("Successfully advanced student " + fn + " to " + course.getClass().getSimpleName() + "!");
                return true;
            }
        }
        return false;
    }
}

