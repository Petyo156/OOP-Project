package commands.logic;

import interfaces.Student;
import student.discipline.Discipline;

import java.util.Scanner;

/**
 * Command class for adding grades to a student's new enrolled disciplines, Also works for changing current grades.
 */
public class AddGrade extends CommandsManager {

    /**
     * Executes the command to add a grade to a specific discipline for a student.
     * @param command The command string containing student ID, course name, and grade.
     */
    @Override
    public void execute(String command) {
        String[] arr = command.toLowerCase().split(" ");

        // Check if the correct number of arguments is provided
        if (arr.length < 4) {
            System.out.println("Enter a valid number of arguments!");
            return;
        }

        String fn = arr[1];

        // Check if the student is interrupted
        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }

        // Check if the student exists
        if (null == findByFakNum(fn)) {
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        String course = arr[2];
        int grade = -1;
        try {
            grade = Integer.parseInt(arr[3]);
            if (grade < 2 || grade > 6) {
                throw new IllegalArgumentException();
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Grade can only be a number between 2-6.");
            return;
        }

        // Set the grade for the specified discipline
        for (Discipline d : findByFakNum(fn).getDisciplines()) {
            if(d.getName().toLowerCase().equals(course)){
                d.setEarnedGrade(grade);
                System.out.println("Grade set successfully!");
                return;
            }
        }

        // If the discipline is not found, print an error message
        System.out.println("Discipline is not included in current student disciplines.");
    }

}