package commands.logic;

import interfaces.Student;

/**
 * Command class, Prints information about a student.
 */
public class Print extends CommandsManager{
    /**
     * This command prints detailed information about a student, including their name, faculty number,
     * speciality, group, status, and list of disciplines.
     *
     * @param command The input command containing the student's faculty number.
     *                The format should be: "print <FN>".
     *                Example: "print 22621624".
     */
    @Override
    public void execute(String command) {
        String[] arr = command.split(" ");
        if(arr.length == 1){
            System.out.println("Enter valid number of arguments!");
            return;
        }
        String fn = arr[1];

        Student student = findByFakNum(fn);
        if(null == student){
            System.out.println("Student " + fn + " not found.");
            return;
        }
        System.out.println("-----------------------------------------------------------");
        System.out.println(student);
        System.out.println("-----------------------------------------------------------");
    }
}
