package commands.logic;

import interfaces.MenuItem;
import interfaces.Repository;
import interfaces.Student;
import student.AllStudents;
import student.discipline.Discipline;
import student.implementation.Status;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Abstract class representing the manager for various commands in the Student Management System,
 * Provides methods for executing commands and performing common operations on students and disciplines.
 */
public abstract class CommandsManager implements MenuItem {

    /** Executes the command. */
    @Override
    public void execute() {}

    /** Executes the command with a specified string argument.
     * @param command The command string to execute.
     */
    @Override
    public void execute(String command) {}

    /**
     * Finds a student by their faculty number.
     * @param fn The faculty number of the student to find.
     * @return The student with the specified faculty number, or null if not found.
     */
    public Student findByFakNum(String fn) {
        List<Student> studentList = AllStudents.getAllStudents();
        return studentList.stream()
                .filter(student1 -> student1.getFakNumber().equals(fn))
                .findFirst()
                .orElse(null);
    }

    /**
     * Checks if a student has good scores in all disciplines.
     * @param student The student to check.
     * @return True if the student has good scores in all disciplines, otherwise false.
     */
    public boolean checkIfGoodScore(Student student){
        boolean canBeAdvanced = true;
        List<String> disciplinesWithLowScore = new ArrayList<>();
        for (Discipline d : student.getDisciplines()) {
            if (d.getEarnedGrade() == 2) {
                disciplinesWithLowScore.add(d.getName());
                canBeAdvanced = false;
            }
        }
        if (!canBeAdvanced) {
            System.out.println("Student " + student.getFakNumber() + " has not succeeded in "
                    + String.join(", ", disciplinesWithLowScore) + " and can't graduate.");
            return false;
        }
        return true;
    }

    /**
     * Checks if a student is in an interrupted status.
     * @param fn The faculty number of the student to check.
     * @return True if the student is in an interrupted status, otherwise false.
     */
    public boolean isInterrupted(String fn){
        if(checkIfStudentIsNull(fn)){
            return false;
        } else {
            return findByFakNum(fn).getStatus().equals(Status.INTERRUPTED);
        }
    }

    /**
     * Checks if a student is in a graduated status.
     * @param fn The faculty number of the student to check.
     * @return True if the student is in a graduated status, otherwise false.
     */
    public boolean isGraduated(String fn){
        if(checkIfStudentIsNull(fn)){
            return false;
        } else {
            return findByFakNum(fn).getStatus().equals(Status.GRADUATED);
        }
    }

    /**
     * Checks if a student with the specified faculty number exists.
     * @param fakNum The faculty number of the student to check.
     * @return True if the student does not exist, otherwise false.
     */
    public boolean checkIfStudentIsNull(String fakNum){
        if(findByFakNum(fakNum) == null){
            return true;
        }
        return false;
    }

    /**
     * Sets the grade for a discipline.
     * @param discipline The discipline for which to set the grade.
     */
    public void setDisciplineGrade(Discipline discipline){
        Scanner scanner = new Scanner(System.in);
        System.out.print(discipline.getName() + " grade - ");
        try {
            int grade = Integer.parseInt(scanner.nextLine());
            try {
                discipline.setEarnedGrade(grade);
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                setDisciplineGrade(discipline);
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input.");
            setDisciplineGrade(discipline);
        }
    }

    /**
     * Gets the earned grade for a discipline of a student.
     * @param student The student whose discipline grade to retrieve.
     * @param disciplineName The name of the discipline.
     * @return The earned grade for the specified discipline of the student, or -1 if not found.
     */
    public int getDisciplineEarnedGrade(Student student, String disciplineName) {
        for (Discipline d : student.getDisciplines()) {
            if(d.getName().toLowerCase().equals(disciplineName)){
                return d.getEarnedGrade();
            }
        }
        return -1;
    }
}