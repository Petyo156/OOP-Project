package commands.logic;

import interfaces.Student;
import student.implementation.Status;

/**
 * Command class, Interrupts a student.
 */
public class Interrupt extends CommandsManager{
    /**
     * This command sets the status of a student to "interrupted".
     *
     * @param command The input command containing the student's faculty number.
     *                The format should be: "interrupt <FN>".
     *                Example: "interrupt 22621624".
     */
    @Override
    public void execute(String command) {
        String[] arr = command.split(" ");
        if(arr.length == 1){
            System.out.println("Enter valid number of arguments!");
            return;
        }
        String fn = arr[1];

        Student student = findByFakNum(fn);
        if(null == student){
            System.out.println("Student " + fn + " not found.");
            return;
        }

        findByFakNum(fn).setStatus(Status.INTERRUPTED);
        System.out.println("Student " + fn + " interrupted successfully!");
    }
}
