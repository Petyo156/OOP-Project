package commands.logic;

import interfaces.Student;
import specialities.Course;
import specialities.SpecialityKind;
import specialities.kst.FirstCourse;
import specialities.kst.FourthCourse;
import specialities.kst.KST;
import specialities.kst.ThirdCourse;
import specialities.sit.SIT;
import specialities.sit.SecondCourse;
import student.AllStudents;
import student.StudentImpl;
import student.StudentRepository;
import student.discipline.Discipline;
import student.implementation.Group;

import java.util.ArrayList;
import java.util.List;

import static specialities.kst.FirstCourse.KST_DISCIPLINES_1;
import static specialities.kst.FourthCourse.KST_DISCIPLINES_4;
import static specialities.kst.SecondCourse.KST_DISCIPLINES_2;
import static specialities.kst.ThirdCourse.KST_DISCIPLINES_3;
import static specialities.sit.FirstCourse.SIT_DISCIPLINES_1;
import static specialities.sit.FourthCourse.SIT_DISCIPLINES_4;
import static specialities.sit.SecondCourse.SIT_DISCIPLINES_2;
import static specialities.sit.ThirdCourse.SIT_DISCIPLINES_3;

/**
 * Command class, Represents a command for changing a student's program, group, or course.
 */
public class Change extends CommandsManager {
    /**
     * Executes the command to change a student's program, group, or course based on the provided command string.
     * @param command The command string containing the details of the change.
     */
    @Override
    public void execute(String command) {
        // Split the command string into an array
        String[] arr = command.toLowerCase().split(" ");

        // Check if the command contains the required arguments
        if (arr.length < 4) {
            System.out.println("Enter valid number of arguments!");
            return;
        }

        // Extract the student's ID, option, and value from the command
        String fn = arr[1];
        String option = arr[2];
        String value = arr[3];

        // Check if the student is interrupted or graduated
        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }
        if (isGraduated(fn)) {
            System.out.println("Student " + fn + " is graduated.");
            return;
        }

        // Check if the student exists
        if(null == findByFakNum(fn)){
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        Student student = findByFakNum(fn);

        switch (option) {
            //Changes the student's program based on the provided value.
            case "program":
                SpecialityKind speciality;
                if (!studentCanTranfer(student)) {
                    System.out.println("Student " + fn + " can't transfer due not passed exams.");
                    return;
                }
                switch (value) {
                    case "sit" -> {
                        String whichCourse = student.getCourse().getClass().getSimpleName();
                        courseSetterSIT(whichCourse, findByFakNum(fn));
                        student.setSpeciality(new SIT());
                    }
                    case "kst" -> {
                        String whichCourse = student.getCourse().getClass().getSimpleName();
                        courseSetterKST(whichCourse, findByFakNum(fn));
                        student.setSpeciality(new KST());
                    }
                    default -> {
                        System.out.println("Invalid program.");
                        return;
                    }
                }
                System.out.println("Program changed to " + value.toUpperCase() + " successfully!");
                break;
            //Changes the student's group based on the provided value.
            case "group":
                switch (value) {
                    case "1a" -> findByFakNum(fn).setGroup(Group.GROUP1A);
                    case "1b" -> findByFakNum(fn).setGroup(Group.GROUP1B);
                    case "2a" -> findByFakNum(fn).setGroup(Group.GROUP2A);
                    case "2b" -> findByFakNum(fn).setGroup(Group.GROUP2B);
                    case "3a" -> findByFakNum(fn).setGroup(Group.GROUP3A);
                    case "3b" -> findByFakNum(fn).setGroup(Group.GROUP3B);
                    default -> {
                        System.out.println("Invalid group.");
                        return;
                    }
                }
                System.out.println("Group set successfully!");
                break;
            //Changes the student's year based on the provided value.
            case "year":
                Advance advance = new Advance();

                boolean canBeAdvanced = true;

                List<String> disciplinesWithLowScore = new ArrayList<>();
                for (Discipline d : student.getDisciplines()) {
                    if (d.getEarnedGrade() == 2) {
                        disciplinesWithLowScore.add(d.getName());
                        canBeAdvanced = false;
                    }
                }
                if (!canBeAdvanced) {
                    System.out.println("Student " + student.getFakNumber() + " has not succeeded in "
                            + String.join(", ", disciplinesWithLowScore) + " and can't be advanced.");
                    return;
                }

                String currentCourseSimpleName = student.getCourse().getClass().getSimpleName();
                boolean shouldAdvance;

                switch (value) {
                    case "secondcourse" -> shouldAdvance = currentCourseSimpleName.equals("FirstCourse");
                    case "thirdcourse" -> shouldAdvance = currentCourseSimpleName.equals("SecondCourse");
                    case "fourthcourse" -> shouldAdvance = currentCourseSimpleName.equals("ThirdCourse");
                    default -> {
                        System.out.println("Invalid course.");
                        return;
                    }
                }

                if (shouldAdvance) {
                    advance.execute("advance " + student.getFakNumber());
                } else {
                    System.out.println("You can't change student's course to " + value + ".");
                }
                break;
            default:
                System.out.println("Invalid option parameter.");
        }
    }

    /**
     * Checks if the student can transfer to another program.
     * This method evaluates whether the student has passed all exams,
     * which is a prerequisite for transferring to a new program.
     *
     * @param student The student object to be checked.
     * @return True if the student can transfer, false otherwise.
     */
    private boolean studentCanTranfer(Student student) {
        int sum = 0;
        for (Discipline d : student.getDisciplines()) {
            if (d.getEarnedGrade() == 2) {
                sum++;
            }
        }
        return sum == 0;
    }

    /**
     * Sets the course of the student to a specified course within the KST speciality.
     * This method removes the student from the current course repository within KST
     * and adds them to the repository corresponding to the specified course.
     *
     * @param courseName The name of the course to be set.
     * @param student The student object whose course is being set.
     */
    private void courseSetterKST(String courseName, Student student) {
        switch (courseName){
            case "FirstCourse" -> SIT.studentRepository1.remove(student);
            case "SecondCourse" -> SIT.studentRepository2.remove(student);
            case "ThirdCourse" -> SIT.studentRepository3.remove(student);
            case "FourthCourse" -> SIT.studentRepository4.remove(student);
        }
        Course course = null;
        switch (courseName) {
            case "FirstCourse" -> {
                KST.studentRepository1.add(student);
                course = new specialities.kst.FirstCourse();
            }
            case "SecondCourse" -> {
                KST.studentRepository2.add(student);
                course = new specialities.kst.SecondCourse();
            }
            case "ThirdCourse" -> {
                KST.studentRepository3.add(student);
                course = new specialities.kst.ThirdCourse();
            }
            case "FourthCourse" -> {
                KST.studentRepository4.add(student);
                course = new specialities.kst.FourthCourse();
            }
        }
        student.setCourse(course);
    }

    /**
     * Sets the course of the student to a specified course within the SIT speciality.
     * This method removes the student from the current course repository within KST
     * and adds them to the repository corresponding to the specified course.
     *
     * @param courseName The name of the course to be set.
     * @param student The student object whose course is being set.
     */
    private void courseSetterSIT(String courseName, Student student) {
        switch (courseName){
            case "FirstCourse" -> KST.studentRepository1.remove(student);
            case "SecondCourse" -> KST.studentRepository2.remove(student);
            case "ThirdCourse" -> KST.studentRepository3.remove(student);
            case "FourthCourse" -> KST.studentRepository4.remove(student);
        }
        Course course = null;
        switch (courseName) {
            case "FirstCourse" -> {
                SIT.studentRepository1.add(student);
                course = new specialities.sit.FirstCourse();
            }
            case "SecondCourse" -> {
                SIT.studentRepository2.add(student);
                course = new specialities.sit.SecondCourse();
            }
            case "ThirdCourse" -> {
                SIT.studentRepository3.add(student);
                course = new specialities.sit.ThirdCourse();
            }
            case "FourthCourse" -> {
                SIT.studentRepository4.add(student);
                course = new specialities.sit.FourthCourse();
            }
        }
        student.setCourse(course);
    }
}
