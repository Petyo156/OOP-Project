package commands.logic;

import interfaces.Student;
import student.discipline.Discipline;
import student.implementation.Status;

import java.util.ArrayList;
import java.util.List;

/**
 * Command class, Graduates a student.
 */
public class Graduate extends CommandsManager{
    /**
     * This command allows graduating a student if they meet the graduation criteria.
     * This command sets the status of a student to "graduated".
     *
     * @param command The input command containing the student's faculty number.
     *                The format should be: "graduate <FN>".
     *                Example: "graduate 22621624".
     */
    @Override
    public void execute(String command) {
        String[] arr = command.split(" ");
        if(arr.length == 1){
            System.out.println("Enter valid number of arguments!");
            return;
        }
        String fn = arr[1];

        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }
        if (isGraduated(fn)) {
            System.out.println("Student " + fn + " is already graduated.");
            return;
        }

        if(null == findByFakNum(fn)){
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        if(!findByFakNum(fn).getCourse().getClass().getSimpleName().equals("FourthCourse")){
            System.out.println("Student " + fn + " is not in fourth course yet.");
            return;
        }

        if(checkIfGoodScore(findByFakNum(fn))){
            findByFakNum(fn).setStatus(Status.GRADUATED);
            System.out.println("Student graduated successfully!");
        }
    }
}
