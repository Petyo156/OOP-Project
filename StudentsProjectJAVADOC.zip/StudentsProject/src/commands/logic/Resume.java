package commands.logic;

import interfaces.Student;
import student.implementation.Status;
/**
 * Command class, Resumes the rights of a previously interrupted student, changing their status to enrolled.
 */
public class Resume extends CommandsManager{
    /**
     * Command class, Resumes the rights of a previously interrupted student, changing their status to enrolled.
     *
     * @param command The input command containing the faculty number of the student.
     *                The format should be: "resume <faculty_number>".
     *                Example: "resume 22621624".
     */
    @Override
    public void execute(String command) {
        String[] arr = command.split(" ");
        if(arr.length == 1){
            System.out.println("Enter valid number of arguments!");
            return;
        }
        String fn = arr[1];

        Student student = findByFakNum(fn);
        if(null == student){
            System.out.println("Student " + fn + " not found.");
            return;
        }

        findByFakNum(fn).setStatus(Status.ENROLLED);
        System.out.println("Restored student rights of the student " + fn + "!");
    }
}
