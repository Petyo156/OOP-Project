package interfaces;

/**
 * Represents a menu item that can be executed.
 */
public interface MenuItem {
    /**
     * Executes the menu item without any arguments.
     */
    void execute();

    /**
     * Executes the menu item with the provided command.
     * @param command The command to execute.
     */
    void execute(String command);
}