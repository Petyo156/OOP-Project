package interfaces;

import specialities.Course;
import student.discipline.Discipline;
import student.implementation.Group;
import student.implementation.Status;

import java.util.List;

/**
 * Represents a student in the Student Management System
 * Provides methods to retrieve student information, manage disciplines, set grades,
 * and manage course-related details.
 */
public interface Student {
    /**
     * Retrieves the name of the student.
     * @return The name of the student.
     */
    String getName();

    /**
     * Adds a discipline to the student's list of disciplines.
     * @param disciplineName The discipline to add.
     */
    void addDiscipline(Discipline disciplineName);

    /**
     * Retrieves the faculty number of the student.
     * @return The faculty number of the student.
     */
    String getFakNumber();

    /**
     * Sets the course of the student.
     * @param course The course to set.
     */
    void setCourse(Course course);

    /**
     * Retrieves the course of the student.
     * @return The course of the student.
     */
    Course getCourse();

    /**
     * Retrieves the list of disciplines associated with the student.
     * @return The list of disciplines.
     */
    List<Discipline> getDisciplines();

    /**
     * Retrieves the group of the student.
     * @return The group of the student.
     */
    Group getGroup();

    /**
     * Sets the group of the student.
     * @param group The group to set.
     */
    void setGroup(Group group);

    /**
     * Sets the status of the student.
     * @param status The status to set.
     */
    void setStatus(Status status);

    /**
     * Retrieves the status of the student.
     * @return The status of the student.
     */
    Status getStatus();

    /**
     * Sets the grades for the student.
     * @param student The student for whom to set grades.
     */
    void setGrades(Student student);

    /**
     * Retrieves the speciality of the student.
     * @return The speciality of the student.
     */
    Speciality getSpeciality();

    /**
     * Sets the speciality of the student.
     * @param speciality The speciality to set.
     */
    void setSpeciality(Speciality speciality);

    /**
     * Retrieves the average score of the student.
     * @return The average score of the student.
     */
    double getAvgScore();
}

