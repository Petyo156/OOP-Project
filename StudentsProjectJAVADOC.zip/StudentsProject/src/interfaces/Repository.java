package interfaces;

import java.util.Collection;

/**
 * Represents a repository for storing and managing entities of type T
 * @param <T> The type of entity stored in the repository.
 */
public interface Repository<T> {
    /**
     * Retrieves the collection of entities stored in the repository.
     * @return The collection of entities.
     */
    Collection<T> getCollection();

    /**
     * Adds an entity to the repository.
     * @param entity The entity to add.
     */
    void add(T entity);

    /**
     * Removes an entity from the repository.
     * @param entity The entity to remove.
     * @return true if the entity was removed successfully, otherwise false.
     */
    boolean remove(T entity);
}