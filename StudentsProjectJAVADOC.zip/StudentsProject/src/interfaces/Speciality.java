package interfaces;

/**
 * Interface helping with readability.
 */
public interface Speciality {
}
