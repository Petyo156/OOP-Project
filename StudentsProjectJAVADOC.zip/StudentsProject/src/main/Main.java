package main;

import menu.Menu;

import java.util.Scanner;

/**
 * The main class responsible for running the program and interacting with the user through the console.
 * It initializes a menu, takes user input, and executes the chosen menu option until the user decides to exit.
 */
public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        Scanner scanner = new Scanner(System.in);
        String choice;
        // Show the menu
        menu.showMenu();
        // Continue taking user input until the user chooses to exit
        do {
            System.out.print("Enter your choice: ");
            choice = scanner.nextLine().toLowerCase();
            if (!choice.equals("exit")) {
                menu.executeOption(choice);
            }
        } while (!choice.equals("exit"));
        System.out.println("Exiting the program...");
        scanner.close();
    }
}
