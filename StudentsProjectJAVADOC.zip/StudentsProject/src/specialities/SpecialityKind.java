package specialities;

import interfaces.Speciality;
import student.StudentImpl;
import student.StudentRepository;
import student.discipline.Discipline;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * An abstract class representing a specialization within a certain field of study.
 * SpecialityKind extends Course and implements the Speciality interface.
 */
public abstract class SpecialityKind extends Course implements Speciality {

    /** The list of disciplines associated with this specialization. */
    private List<Discipline> disciplines;

    /**
     * Constructs a new SpecialityKind object.
     * Initializes the list of disciplines.
     */
    public SpecialityKind() {
        disciplines = new ArrayList<>();
    }

    /**
     * Sets the disciplines associated with this specialization.
     * @param disciplines The list of disciplines to set.
     */
    public void setDisciplines(List<Discipline> disciplines) {
        this.disciplines.addAll(disciplines);
    }

    /**
     * Returns a string representation of this SpecialityKind object.
     * @return A string containing the simple name of the class.
     */
    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }
}