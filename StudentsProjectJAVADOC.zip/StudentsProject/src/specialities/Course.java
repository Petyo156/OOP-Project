package specialities;

import interfaces.Speciality;

/**
 * An abstract class helping readability.
 */
public abstract class Course {

}