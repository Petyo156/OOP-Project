package specialities.sit;

import specialities.SpecialityKind;
import student.AllStudents;
import student.StudentRepository;

import static student.AllStudents.addSITStudentRepository;
import static student.AllStudents.addStudentRepository;

/**
 * Represents the SIT (Software Engineering and Information Technologies) specialty in the Student Management System.
 * Extends the SpecialityKind class to provide functionality specific to the SIT specialty.
 */
public class SIT extends SpecialityKind {
    /**
     * Student repositories for the SIT specialty. FirstCourse, SecondCourse, ThirdCourse, FourthCourse
     */
    public static StudentRepository studentRepository1 = new StudentRepository();
    public static StudentRepository studentRepository2 = new StudentRepository();
    public static StudentRepository studentRepository3 = new StudentRepository();
    public static StudentRepository studentRepository4 = new StudentRepository();

    static{
        // Add student repositories to the global student list and SIT student list
        addStudentRepository(studentRepository1);
        addStudentRepository(studentRepository2);
        addStudentRepository(studentRepository3);
        addStudentRepository(studentRepository4);

        addSITStudentRepository(studentRepository1);
        addSITStudentRepository(studentRepository2);
        addSITStudentRepository(studentRepository3);
        addSITStudentRepository(studentRepository4);
    }
}
