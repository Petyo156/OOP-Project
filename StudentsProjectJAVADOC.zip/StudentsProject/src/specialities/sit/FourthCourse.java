package specialities.sit;

import student.discipline.Discipline;
import student.discipline.mandatory.sit.*;

import java.util.List;

/**
 * Represents the fourth course and includes a list of disciplines for the fourth course of the SIT specialty.
 */
public class FourthCourse extends SIT {
    /**
     * List of disciplines for the fourth course of the SIT specialty.
     */
    public static final List<Discipline> SIT_DISCIPLINES_4 = List.of(new OOP2(), new WEBProgramming());

    /**
     * Constructs a FourthCourse object and sets the disciplines for the fourth course.
     */
    public FourthCourse() {
        super.setDisciplines(SIT_DISCIPLINES_4);
    }
}