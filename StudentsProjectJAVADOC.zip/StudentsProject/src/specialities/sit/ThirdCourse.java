package specialities.sit;

import student.discipline.Discipline;
import student.discipline.mandatory.sit.*;

import java.util.List;

/**
 * Represents the third course and includes a list of disciplines for the third course of the SIT specialty.
 */
public class ThirdCourse extends SIT {
    /**
     * List of disciplines for the third course of the SIT specialty.
     */
    public static final List<Discipline> SIT_DISCIPLINES_3 = List.of(new PS(), new GS());

    /**
     * Constructs a ThirdCourse object and sets the disciplines for the third course.
     */
    public ThirdCourse() {
        super.setDisciplines(SIT_DISCIPLINES_3);
    }
}