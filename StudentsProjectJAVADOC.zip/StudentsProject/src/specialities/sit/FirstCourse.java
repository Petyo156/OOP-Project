package specialities.sit;

import student.discipline.Discipline;
import student.discipline.mandatory.sit.English;
import student.discipline.mandatory.sit.OK;
import student.discipline.mandatory.sit.OOP;
import student.discipline.mandatory.sit.WEBDesign;

import java.util.List;

/**
 * Represents the first course and includes a list of disciplines for the first course of the SIT specialty.
 */
public class FirstCourse extends SIT {
    /**
     * List of disciplines for the first course of the SIT specialty.
     */
    public static final List<Discipline> SIT_DISCIPLINES_1 = List.of(new English(), new WEBDesign());

    /**
     * Constructs a FirstCourse object and sets the disciplines for the first course.
     */
    public FirstCourse() {
        super.setDisciplines(SIT_DISCIPLINES_1);
    }
}