package specialities.sit;

import student.discipline.Discipline;
import student.discipline.mandatory.sit.English;
import student.discipline.mandatory.sit.OK;
import student.discipline.mandatory.sit.OOP;
import student.discipline.mandatory.sit.OOP2;

import java.util.List;

/**
 * Represents the second course and includes a list of disciplines for the second course of the SIT specialty.
 */
public class SecondCourse extends SIT {
    /**
     * List of disciplines for the second course of the SIT specialty.
     */
    public static final List<Discipline> SIT_DISCIPLINES_2 = List.of(new OOP(), new OK());

    /**
     * Constructs a SecondCourse object and sets the disciplines for the second course.
     */
    public SecondCourse() {
        super.setDisciplines(SIT_DISCIPLINES_2);
    }
}