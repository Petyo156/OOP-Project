package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.kst.German;
import student.discipline.mandatory.kst.HardwareBasics;

import java.util.List;

/**
 * Represents first course and includes a list of disciplines for the first course of the KST specialty.
 */
public class FirstCourse extends KST {
    /**
     * List of disciplines for the first course of the KST specialty.
     */
    public static final List<Discipline> KST_DISCIPLINES_1 = List.of(new HardwareBasics(), new German());

    /**
     * Constructs a FirstCourse object and sets the disciplines for the first course.
     */
    public FirstCourse() {
        super.setDisciplines(KST_DISCIPLINES_1);
    }
}
