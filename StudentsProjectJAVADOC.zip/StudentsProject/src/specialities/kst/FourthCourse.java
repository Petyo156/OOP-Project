package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.kst.Microcontrollers;
import student.discipline.mandatory.kst.Robotics;

import java.util.List;

/**
 * Represents the fourth course and includes a list of disciplines for the fourth course of the KST specialty.
 */
public class FourthCourse extends KST {
    /**
     * List of disciplines for the fourth course of the KST specialty.
     */
    public static final List<Discipline> KST_DISCIPLINES_4 = List.of(new Microcontrollers(), new Robotics());

    /**
     * Constructs a FourthCourse object and sets the disciplines for the fourth course.
     */
    public FourthCourse() {
        super.setDisciplines(KST_DISCIPLINES_4);
    }
}