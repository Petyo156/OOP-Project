package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.kst.IOTDevelopment;
import student.discipline.mandatory.kst.Mechatronics;
import student.discipline.mandatory.sit.English;
import student.discipline.mandatory.sit.OK;
import student.discipline.mandatory.sit.OOP;

import java.util.List;

/**
 * Represents the third course and includes a list of disciplines for the third course of the KST specialty.
 */
public class ThirdCourse extends KST {
    /**
     * List of disciplines for the third course of the KST specialty.
     */
    public static final List<Discipline> KST_DISCIPLINES_3 = List.of(new Mechatronics(), new IOTDevelopment());

    /**
     * Constructs a ThirdCourse object and sets the disciplines for the third course.
     */
    public ThirdCourse() {
        super.setDisciplines(KST_DISCIPLINES_3);
    }
}