package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.kst.AssemblerProgramming;
import student.discipline.mandatory.kst.DigitalSystems;
import student.discipline.mandatory.sit.English;
import student.discipline.mandatory.sit.OK;
import student.discipline.mandatory.sit.OOP;

import java.util.List;

/**
 * Represents the second course and includes a list of disciplines for the second course of the KST specialty.
 */
public class SecondCourse extends KST {
    /**
     * List of disciplines for the second course of the KST specialty.
     */
    public static final List<Discipline> KST_DISCIPLINES_2 = List.of(new DigitalSystems(), new AssemblerProgramming());

    /**
     * Constructs a SecondCourse object and sets the disciplines for the second course.
     */
    public SecondCourse() {
        super.setDisciplines(KST_DISCIPLINES_2);
    }
}