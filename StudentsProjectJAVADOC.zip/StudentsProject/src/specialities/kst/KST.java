package specialities.kst;

import specialities.SpecialityKind;
import student.AllStudents;
import student.StudentRepository;

import static student.AllStudents.*;

/**
 * Represents the KST (Computer Systems and Technologies) specialty in the Student Management System.
 * Extends the SpecialityKind class to provide functionality specific to the KST specialty.
 */
public class KST extends SpecialityKind {
    /**
     * Student repositories for the KST specialty. FirstCourse, SecondCourse, ThirdCourse, FourthCourse
     */
    public static StudentRepository studentRepository1 = new StudentRepository();
    public static StudentRepository studentRepository2 = new StudentRepository();
    public static StudentRepository studentRepository3 = new StudentRepository();
    public static StudentRepository studentRepository4 = new StudentRepository();


    static{
        // Add student repositories to the global student list and KST student list
        addStudentRepository(studentRepository1);
        addStudentRepository(studentRepository2);
        addStudentRepository(studentRepository3);
        addStudentRepository(studentRepository4);

        addKSTStudentRepository(studentRepository1);
        addKSTStudentRepository(studentRepository2);
        addKSTStudentRepository(studentRepository3);
        addKSTStudentRepository(studentRepository4);
    }
}

