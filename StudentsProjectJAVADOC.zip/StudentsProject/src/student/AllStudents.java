package student;

import interfaces.Student;
import student.StudentRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * Class representing a container for all students and their repositories in the Student Management System.
 */
public class AllStudents {

    /** List containing all student repositories. */
    public static List<StudentRepository> ALL_STUDENTS = new ArrayList<>();

    /** List containing student repositories for the SIT speciality. */
    public static List<StudentRepository> SIT_STUDENTS = new ArrayList<>();

    /** List containing student repositories for the KST speciality. */
    public static List<StudentRepository> KST_STUDENTS = new ArrayList<>();

    /** Adds a student repository to the list of all students.
     * @param studentRepository The student repository to add.
     */
    public static void addStudentRepository(StudentRepository studentRepository) {
        ALL_STUDENTS.add(studentRepository);
    }

    /** Adds a student repository to the list of SIT students.
     * @param studentRepository The student repository to add.
     */
    public static void addSITStudentRepository(StudentRepository studentRepository) {
        SIT_STUDENTS.add(studentRepository);
    }

    /** Adds a student repository to the list of KST students.
     * @param studentRepository The student repository to add.
     */
    public static void addKSTStudentRepository(StudentRepository studentRepository) {
        KST_STUDENTS.add(studentRepository);
    }

    /** List containing all students from all repositories. */
    public static List<Student> allStudents = new ArrayList<>();

    /**
     * Retrieves a list of all students from all repositories.
     * @return A list containing all students.
     */
    public static List<Student> getAllStudents() {
        for (StudentRepository studentRepository : ALL_STUDENTS) {
            allStudents.addAll(studentRepository.getCollection());
        }
        return allStudents;
    }
}