package student;

import interfaces.Speciality;
import interfaces.Student;
import specialities.Course;
import specialities.SpecialityKind;
import student.discipline.*;
import student.implementation.Group;
import student.implementation.Status;

import java.util.*;

/**
 * Represents a student in the student management system.
 */
public class StudentImpl implements Student {
    // Attributes
    private List<Discipline> disciplineList; // List of disciplines for the student
    private String name; // Name of the student
    private String fakNumber; // Unique identifier for the student
    private Course course; // Current course of the student
    private SpecialityKind speciality; // Specialization of the student
    private Group group; // Group of the student
    private Status status; // Status of the student
    private double avgScore; // Average score of the student

    /**
     * Constructor to initialize a student.
     *
     * @param name       Name of the student
     * @param fakNumber  Unique identifier for the student
     * @param course     Current course of the student
     * @param speciality Specialization of the student
     * @param group      Group of the student
     * @param status     Status of the student
     */
    public StudentImpl(String name, String fakNumber,
                       Course course, Speciality speciality, Group group, Status status) {
        this.disciplineList = new ArrayList<>();
        this.name = name;
        this.fakNumber = fakNumber;
        this.avgScore = 0;
        this.course = course;
        this.speciality = (SpecialityKind) speciality;
        this.group = group;
        this.status = status;
    }

    /**
     * Retrieves the name of the student.
     *
     * @return The name of the student
     */
    @Override
    public String getName() {
        return this.name;
    }

    /**
     * Adds a discipline to the student's list of disciplines.
     *
     * @param discipline The discipline to be added
     */
    @Override
    public void addDiscipline(Discipline discipline) {
        this.disciplineList.add(discipline);
    }

    /**
     * Retrieves the unique identifier of the student.
     *
     * @return The unique identifier of the student
     */
    @Override
    public String getFakNumber() {
        return fakNumber;
    }

    /**
     * Sets the current course of the student.
     *
     * @param course The course to be set
     */
    @Override
    public void setCourse(Course course) {
        this.course = course;
    }

    /**
     * Retrieves the current course of the student.
     *
     * @return The current course of the student
     */
    @Override
    public Course getCourse() {
        return this.course;
    }

    /**
     * Retrieves the list of disciplines of the student.
     *
     * @return The list of disciplines of the student
     */
    @Override
    public List<Discipline> getDisciplines() {
        return this.disciplineList;
    }

    /**
     * Retrieves the group of the student.
     *
     * @return The group of the student
     */
    @Override
    public Group getGroup() {
        return group;
    }

    /**
     * Sets the group of the student.
     *
     * @param group The group to be set
     */
    @Override
    public void setGroup(Group group) {
        this.group = group;
    }

    /**
     * Sets the status of the student.
     *
     * @param status The status to be set
     */
    @Override
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * Retrieves the status of the student.
     *
     * @return The status of the student
     */
    @Override
    public Status getStatus() {
        return this.status;
    }

    /**
     * Sets the grades for the student.
     *
     * @param student The student whose grades are to be set
     */
    @Override
    public void setGrades(Student student) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Set student grades for the current course: ");
        for (Discipline discipline : getDisciplines()) {
            System.out.print(discipline.getName() + " grade - ");
            try {
                int grade = Integer.parseInt(scanner.nextLine());
                try {
                    discipline.setEarnedGrade(grade);
                    student.addDiscipline(discipline);
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                    setGrades(student);
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input.");
                setGrades(student);
            }
        }
    }

    /**
     * Retrieves the specialization of the student.
     *
     * @return The specialization of the student
     */
    @Override
    public Speciality getSpeciality() {
        return this.speciality;
    }

    /**
     * Sets the specialization of the student.
     *
     * @param speciality The specialization to be set
     */
    @Override
    public void setSpeciality(Speciality speciality) {
        this.speciality = (SpecialityKind) speciality;
    }

    /**
     * Calculates the average score of the student.
     *
     * @return The average score of the student
     */
    @Override
    public double getAvgScore() {
        double count = 0;
        double sum = 0;
        for (Discipline d : disciplineList) {
            count++;
            if (d.getEarnedGrade() == -1) {
                sum += 2;
            } else {
                sum += d.getEarnedGrade();
            }
        }
        double result = sum / count;
        return result;
    }

    /**
     * Returns a string representation of the student.
     *
     * @return A string representation of the student
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Name: " + name + ", ");
        sb.append(fakNumber + "\n");
        sb.append("Speciality: " + speciality + ", ");
        sb.append(course + "\n");
        sb.append("Disciplines: " + disciplineList.toString() + "\n");
        sb.append(group + ", ");
        sb.append("Status: " + status + "\n");
        sb.append("Avg score: " + String.format("%.2f", getAvgScore()));
        return sb.toString();
    }
}