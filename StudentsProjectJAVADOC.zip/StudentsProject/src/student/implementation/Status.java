package student.implementation;

/**
 * Enum representing the status of a student.
 * It can be one of the following: ENROLLED, INTERRUPTED, GRADUATED.
 * ENROLLED: The student is currently enrolled.
 * INTERRUPTED: The student's enrollment has been interrupted.
 * GRADUATED: The student has graduated.
 */
public enum Status {
    ENROLLED, INTERRUPTED, GRADUATED
}
