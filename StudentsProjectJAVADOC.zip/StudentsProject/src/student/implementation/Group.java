package student.implementation;

/**
 * Enum representing the groups of students.
 * Groups are categorized as GROUP1A, GROUP2A, GROUP3A, GROUP1B, GROUP2B, GROUP3B.
 */
public enum Group {
    GROUP1A, GROUP2A, GROUP3A, GROUP1B, GROUP2B, GROUP3B
}
