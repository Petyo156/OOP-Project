package student;

import interfaces.Repository;
import interfaces.Student;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Represents a repository for storing and managing student entities.
 */
public class StudentRepository implements Repository<Student> {
    /** Collection to store student entities. */
    private Collection<Student> students;

    /**
     * Constructs a new StudentRepository with an empty collection of students.
     */
    public StudentRepository() {
        this.students = new ArrayList<>();
    }

    /**
     * Retrieves the collection of students stored in this repository.
     * @return The collection of students.
     */
    @Override
    public Collection<Student> getCollection() {
        return this.students;
    }

    /**
     * Adds a student entity to the repository.
     * @param entity The student entity to add.
     */
    @Override
    public void add(Student entity) {
        this.students.add(entity);
    }

    /**
     * Removes a student entity from the repository.
     *
     * @param entity The student entity to remove.
     */
    @Override
    public boolean remove(Student entity) {
        return this.students.remove(entity);
    }

    /**
     * Retrieves a string representation of the repository, listing all students.
     * @return A string representation of the repository.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Student s : students) {
            sb.append(s.toString()).append("\n");
        }
        return sb.toString();
    }

    /**
     * Finds a student entity in the repository by their faculty number.
     * @param fakNumber The faculty number of the student to find.
     * @return The student entity with the given faculty number, or null if not found.
     */
    public Student findByFakNum(String fakNumber) {
        return students.stream().filter(student -> student.getFakNumber()
                        .equals(fakNumber))
                .findFirst()
                .orElse(null);
    }
}