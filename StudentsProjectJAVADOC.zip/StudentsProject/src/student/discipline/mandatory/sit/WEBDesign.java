package student.discipline.mandatory.sit;

import student.discipline.Discipline;

/**
 * Mandatory SIT discipline class.
 */
public class WEBDesign extends Discipline {

    public WEBDesign() {
        super(-1, -1);
    }
}
