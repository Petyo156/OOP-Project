package student.discipline.mandatory.sit;

import student.discipline.Discipline;

/**
 * Mandatory SIT discipline class.
 */
public class OOP extends Discipline {

    public OOP() {
        super(-1, -1);
    }
}
