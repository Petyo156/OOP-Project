package student.discipline.mandatory.sit;

import student.discipline.Discipline;

/**
 * Mandatory SIT discipline class.
 */
public class WEBProgramming extends Discipline {
    public WEBProgramming() {
        super(-1, -1);
    }
}
