package student.discipline.mandatory.sit;

import student.discipline.Discipline;

/**
 * Mandatory SIT discipline class.
 */
public class OOP2 extends Discipline {
    public OOP2() {
        super(-1, -1);
    }
}
