package student.discipline.mandatory.kst;

import student.discipline.Discipline;

/**
 * Mandatory KST discipline class.
 */
public class German extends Discipline {
    public German() {
        super(-1, -1);
    }
}
