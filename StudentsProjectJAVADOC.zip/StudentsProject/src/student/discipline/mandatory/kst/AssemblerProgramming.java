package student.discipline.mandatory.kst;

import student.discipline.Discipline;

/**
 * Mandatory KST discipline class.
 */
public class AssemblerProgramming extends Discipline {
    public AssemblerProgramming() {
        super(-1, -1);
    }
}
