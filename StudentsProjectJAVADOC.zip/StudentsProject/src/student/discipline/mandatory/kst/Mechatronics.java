package student.discipline.mandatory.kst;

import student.discipline.Discipline;

/**
 * Mandatory KST discipline class.
 */
public class Mechatronics extends Discipline {
    public Mechatronics() {
        super(-1, -1);
    }
}
