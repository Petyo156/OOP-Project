package student.discipline.optional.kst;

import student.discipline.Discipline;

/**
 * Discipline class, can be enrolled to KST SecondCourse, ThirdCourse, FourthCourse student's disciplines.
 */
public class Electronics extends Discipline {
    public Electronics() {
        super(2, -1);
    }
}
