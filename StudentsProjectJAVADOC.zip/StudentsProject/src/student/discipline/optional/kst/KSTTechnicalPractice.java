package student.discipline.optional.kst;

import student.discipline.Discipline;

/**
 * Discipline class, can be enrolled to KST ThirdCourse, FourthCourse student's disciplines.
 */
public class KSTTechnicalPractice extends Discipline {
    public KSTTechnicalPractice() {
        super(3, -1);
    }
}
