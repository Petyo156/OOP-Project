package student.discipline.optional;

import student.discipline.Discipline;

/**
 * Discipline class, can be enrolled to any student's disciplines.
 */
public class ProgrammingConsultation extends Discipline {
    public ProgrammingConsultation() {
        super(1, -1);
    }
}
