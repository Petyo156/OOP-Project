package student.discipline.optional.sit;

import student.discipline.Discipline;

/**
 * Discipline class, can be enrolled to SIT SecondCourse, ThirdCourse, FourthCourse student's disciplines.
 */
public class AdvancedProgramming extends Discipline {
    public AdvancedProgramming() {
        super(2, -1);
    }
}
