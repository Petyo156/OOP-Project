package student.discipline.optional.sit;

import student.discipline.Discipline;

/**
 * Discipline class, can be enrolled to SIT ThirdCourse, FourthCourse student's disciplines.
 */
public class SITTechnicalPractice extends Discipline {
    public SITTechnicalPractice() {
        super(3, -1);
    }
}
