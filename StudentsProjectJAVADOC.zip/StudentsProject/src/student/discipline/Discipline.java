package student.discipline;

/**
 * Abstract class representing a discipline in the Student Management System.
 */
public abstract class Discipline {
    /**
     * The course level at which this discipline can be added to a student's list of disciplines.
     * If it is a mandatory discipline, the default value is -1.
     */
    private int courseNeeded;


    /** The grade earned in this discipline. */
    private int earnedGrade;

    /**
     * Constructor for Discipline class.
     * @param courseNeeded The course level at which this discipline can be added to a student's list of disciplines.
     * @param earnedGrade The grade earned in this discipline.
     */
    public Discipline(int courseNeeded, int earnedGrade) {
        this.courseNeeded = courseNeeded;
        this.earnedGrade = earnedGrade;
    }

    /**
     * Retrieves the earned grade in this discipline.
     * If the discipline is optional and/or a grade is not set, the default value is -1.
     * @return The earned grade.
     */
    public int getEarnedGrade() {
        return earnedGrade;
    }

    /**
     * Sets the earned grade for this discipline.
     * @param earnedGrade The earned grade to set.
     * @throws IllegalArgumentException if the grade is not between 2 and 6.
     */
    public void setEarnedGrade(int earnedGrade) {
        if(earnedGrade < 2 || earnedGrade > 6){
            throw new IllegalArgumentException("Grade must be between 2 and 6!");
        }
        this.earnedGrade = earnedGrade;
    }

    /**
     * Retrieves the name of this discipline.
     * @return The name of the discipline.
     */
    public String getName(){
        return this.getClass().getSimpleName();
    }

    /**
     * Retrieves the course level at which this discipline can be added to a student's list of disciplines.
     * @return The course level.
     */
    public int getCourseNeeded(){
        return this.courseNeeded;
    }

    /**
     * Generates a string representation of this discipline.
     * @return The string representation.
     */
    @Override
    public String toString() {
        return getName() + "->" + getEarnedGrade();
    }
}