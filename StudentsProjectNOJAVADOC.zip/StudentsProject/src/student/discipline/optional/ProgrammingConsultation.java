package student.discipline.optional;

import student.discipline.Discipline;

public class ProgrammingConsultation extends Discipline {
    public ProgrammingConsultation() {
        super(1, -1);
    }
}
