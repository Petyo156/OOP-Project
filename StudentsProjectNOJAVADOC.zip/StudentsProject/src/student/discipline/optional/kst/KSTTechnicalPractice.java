package student.discipline.optional.kst;

import student.discipline.Discipline;

public class KSTTechnicalPractice extends Discipline {
    public KSTTechnicalPractice() {
        super(3, -1);
    }
}
