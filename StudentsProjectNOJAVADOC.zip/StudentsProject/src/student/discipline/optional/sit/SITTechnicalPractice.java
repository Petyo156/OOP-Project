package student.discipline.optional.sit;

import student.discipline.Discipline;

public class SITTechnicalPractice extends Discipline {
    public SITTechnicalPractice() {
        super(3, -1);
    }
}
