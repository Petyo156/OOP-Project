package student.discipline.mandatory.kst;

import student.discipline.Discipline;

public class Robotics extends Discipline {
    public Robotics() {
        super(-1, -1);
    }
}
