package student.discipline.mandatory.kst;

import student.discipline.Discipline;

public class HardwareBasics extends Discipline {
    public HardwareBasics() {
        super(-1, -1);
    }
}
