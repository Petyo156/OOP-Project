package student.discipline.mandatory.kst;

import student.discipline.Discipline;

public class Mechatronics extends Discipline {
    public Mechatronics() {
        super(-1, -1);
    }
}
