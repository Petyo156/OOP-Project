package student.discipline.mandatory.sit;

import student.discipline.Discipline;

public class WEBDesign extends Discipline {

    public WEBDesign() {
        super(-1, -1);
    }
}
