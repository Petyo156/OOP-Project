package student.implementation;

public enum Group {
    GROUP1A, GROUP2A, GROUP3A, GROUP1B, GROUP2B, GROUP3B
}
