
import menu.Menu;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        Scanner scanner = new Scanner(System.in);
        String choice;
        menu.showMenu();
        do {
            System.out.print("Enter your choice: ");
            choice = scanner.nextLine().toLowerCase();
            if (!choice.equals("exit")) {
                menu.executeOption(choice);
            }
        } while (!choice.equals("exit"));
        System.out.println("Exiting the program...");
        scanner.close();
    }
}

//System.out.println(SIT.studentRepository1.getCollection());
//System.out.println(SIT.studentRepository2.getCollection());
//System.out.println(SIT.studentRepository3.getCollection());
//System.out.println(SIT.studentRepository4.getCollection());

//System.out.println(KST.studentRepository1.getCollection());
//System.out.println(KST.studentRepository2.getCollection());
//System.out.println(KST.studentRepository3.getCollection());
//System.out.println(KST.studentRepository4.getCollection());