package commands.files;

import java.util.List;

public class SaveAs extends FileManager{
    @Override
    public void execute() {

    }

    @Override
    public void execute(String command) {
        List<String> args = List.of(command.split(" "));
        if (args.size() != 2) {
            System.out.println("This command requires 2 arguments!");
            return;
        }
        if (FileManager.getFile() != null) {
            String currentFile = FileManager.getFile().getName();
            FileManager.closeFile();
            FileManager.openFile(args.get(1));
            FileManager.save();
            FileManager.closeFile();
            FileManager.openFile(currentFile);
        } else {
            FileManager.openFile(args.get(1));
            FileManager.save();
            FileManager.closeFile();
        }
        Close close = new Close();
        close.execute("close");
    }
}
