package commands.files;

import java.util.List;

public class Open extends FileManager {
    @Override
    public void execute() {

    }

    @Override
    public void execute(String command) {
        List<String> args = List.of(command.split(" "));
        if (args.size() == 2) {
            String fileName = args.get(1);
            if(FileManager.openFile(fileName)){
                System.out.println("File " + FileManager.getFile().getName() + " successfully opened!");
            }
            else System.out.println("You need to close the currently opened file!");
        }
        else System.out.println("This command requires 1 argument!");
    }
}
