package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.kst.German;
import student.discipline.mandatory.kst.HardwareBasics;

import java.util.List;

public class FirstCourse extends KST {
    public static final List<Discipline> KST_DISCIPLINES_1 = List.of(new HardwareBasics(), new German());

    public FirstCourse() {
        super.setDisciplines(KST_DISCIPLINES_1);
    }
}
