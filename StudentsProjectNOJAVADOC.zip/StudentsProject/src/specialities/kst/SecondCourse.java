package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.kst.AssemblerProgramming;
import student.discipline.mandatory.kst.DigitalSystems;
import student.discipline.mandatory.sit.English;
import student.discipline.mandatory.sit.OK;
import student.discipline.mandatory.sit.OOP;

import java.util.List;

public class SecondCourse extends KST{
    public static final List<Discipline> KST_DISCIPLINES_2 = List.of(new DigitalSystems(), new AssemblerProgramming());

    public SecondCourse() {
        super.setDisciplines(KST_DISCIPLINES_2);
    }
}
