package specialities.sit;

import student.discipline.Discipline;
import student.discipline.mandatory.sit.English;
import student.discipline.mandatory.sit.OK;
import student.discipline.mandatory.sit.OOP;
import student.discipline.mandatory.sit.OOP2;

import java.util.List;

public class SecondCourse extends SIT{
    public static final List<Discipline> SIT_DISCIPLINES_2 = List.of(new OOP(), new OK());

    public SecondCourse() {
        super.setDisciplines(SIT_DISCIPLINES_2);
    }
}
