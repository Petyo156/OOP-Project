package commands.files;

import interfaces.Speciality;
import interfaces.Student;
import specialities.Course;
import specialities.kst.FirstCourse;
import specialities.kst.KST;
import specialities.sit.SIT;
import student.AllStudents;
import student.StudentImpl;
import student.discipline.Discipline;
import student.discipline.mandatory.kst.*;
import student.discipline.mandatory.sit.*;
import student.discipline.optional.ProgrammingConsultation;
import student.discipline.optional.kst.Electronics;
import student.discipline.optional.kst.KSTTechnicalPractice;
import student.discipline.optional.sit.AdvancedProgramming;
import student.discipline.optional.sit.SITTechnicalPractice;
import student.implementation.Group;
import student.implementation.Status;

import java.io.*;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataHandler {

    public static String saveData() {
        StringBuilder xmlData = new StringBuilder();
        xmlData.append("<Students>\n");
        Set<Student> studentSet = new LinkedHashSet<>(AllStudents.getAllStudents());
        for (Student student : studentSet) {
            xmlData.append("<Student>\n");
            xmlData.append("<Name>").append(student.getName()).append("</Name>\n");
            xmlData.append("<FakNumber>").append(student.getFakNumber()).append("</FakNumber>\n");
            xmlData.append("<Course>").append(student.getCourse().getClass().getSimpleName()).append("</Course>\n");
            xmlData.append("<Speciality>").append(student.getSpeciality().getClass().getSimpleName()).append("</Speciality>\n");
            xmlData.append("<Group>").append(student.getGroup()).append("</Group>\n");
            xmlData.append("<Status>").append(student.getStatus()).append("</Status>\n");
            xmlData.append("<Disciplines>").append(student.getDisciplines()).append("</Disciplines>\n");
            xmlData.append("</Student>\n");
        }
        xmlData.append("</Students>\n");
        return xmlData.toString();
    }

    public static void loadData() {
        if (FileManager.getFile() == null) {
            System.out.println("No file opened to load data from.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FileManager.getFile()))) {
            StringBuilder xmlData = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                xmlData.append(line);
            }
            convert(xmlData.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String extractValue(String record, String startTag, String endTag) {
        int startIndex = record.indexOf(startTag);
        if (startIndex != -1) {
            startIndex += startTag.length();
            int endIndex = record.indexOf(endTag, startIndex);
            if (endIndex != -1) {
                return record.substring(startIndex, endIndex);
            }
        }
        return "";
    }

    private static void convert(String data) {
        String[] studentRecords = data.split("</Student>");

        for (String studentRecord : studentRecords) {
            if (studentRecord.trim().isEmpty()) {
                continue;
            }
            String name = extractValue(studentRecord, "<Name>", "</Name>");
            String fakNumber = extractValue(studentRecord, "<FakNumber>", "</FakNumber>");
            String course = extractValue(studentRecord, "<Course>", "</Course>");
            String speciality = extractValue(studentRecord, "<Speciality>", "</Speciality>");
            String group = extractValue(studentRecord, "<Group>", "</Group>");
            String status = extractValue(studentRecord, "<Status>", "</Status>");
            String disciplines = extractValue(studentRecord, "<Disciplines>", "</Disciplines>");


            if (name.isEmpty() || fakNumber.isEmpty() || course.isEmpty() || speciality.isEmpty() || group.isEmpty() || status.isEmpty()) {
                continue;
            }

            Speciality specialityObject = createSpeciality(speciality);
            Course courseObject = createCourse(course, specialityObject);
            Group groupObject = createGroup(group);
            Status statusObject = createStatus(status);

            StudentImpl student = new StudentImpl(name, fakNumber, courseObject, specialityObject, groupObject, statusObject);

            parseDisciplines(disciplines, student);

            if (speciality.equals("SIT")) {
                switch (course) {
                    case "FirstCourse" -> SIT.studentRepository1.add(student);
                    case "SecondCourse" -> SIT.studentRepository2.add(student);
                    case "ThirdCourse" -> SIT.studentRepository3.add(student);
                    case "FourthCourse" -> SIT.studentRepository4.add(student);
                }
            } else if (speciality.equals("KST")) {
                switch (course) {
                    case "FirstCourse" -> KST.studentRepository1.add(student);
                    case "SecondCourse" -> KST.studentRepository2.add(student);
                    case "ThirdCourse" -> KST.studentRepository3.add(student);
                    case "FourthCourse" -> KST.studentRepository4.add(student);
                }
            }
        }
    }

    private static Speciality createSpeciality(String speciality) {
        switch (speciality) {
            case "SIT":
                return new SIT();
            case "KST":
                return new KST();
            default:
                throw new IllegalStateException("Unexpected value for speciality: " + speciality);
        }
    }

    private static Course createCourse(String course, Speciality speciality) {
        switch (course) {
            case "FirstCourse":
                return speciality instanceof KST ? new FirstCourse() : new specialities.sit.FirstCourse();
            case "SecondCourse":
                return speciality instanceof KST ? new specialities.kst.SecondCourse() : new specialities.sit.SecondCourse();
            case "ThirdCourse":
                return speciality instanceof KST ? new specialities.kst.ThirdCourse() : new specialities.sit.ThirdCourse();
            case "FourthCourse":
                return speciality instanceof KST ? new specialities.kst.FourthCourse() : new specialities.sit.FourthCourse();
            default:
                throw new IllegalStateException("Unexpected value for course: " + course);
        }
    }

    private static Group createGroup(String group) {
        return switch (group) {
            case "GROUP1A" -> Group.GROUP1A;
            case "GROUP2A" -> Group.GROUP2A;
            case "GROUP3A" -> Group.GROUP3A;
            case "GROUP1B" -> Group.GROUP1B;
            case "GROUP2B" -> Group.GROUP2B;
            case "GROUP3B" -> Group.GROUP3B;
            default -> throw new IllegalStateException("Unexpected value for group: " + group);
        };
    }

    private static Status createStatus(String status) {
        return switch (status) {
            case "ENROLLED" -> Status.ENROLLED;
            case "INTERRUPTED" -> Status.INTERRUPTED;
            case "GRADUATED" -> Status.GRADUATED;
            default -> throw new IllegalStateException("Unexpected value for status: " + status);
        };
    }

    private static void parseDisciplines(String disciplines, StudentImpl student) {
        String regex = "(\\w+->\\d+)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(disciplines);

        while (matcher.find()) {
            String[] arr = matcher.group(1).split("->");
            String disciplineName = arr[0];
            int earnedGrade = Integer.parseInt(arr[1]);

            Discipline discipline = createDiscipline(disciplineName);
            if (discipline != null) {
                discipline.setEarnedGrade(earnedGrade);
                student.addDiscipline(discipline);
            } else {
                System.out.println("Unknown discipline: " + disciplineName);
            }
        }
    }

    private static Discipline createDiscipline(String disciplineName) {
        return switch (disciplineName) {
            case "AssemblerProgramming" -> new AssemblerProgramming();
            case "DigitalSystems" -> new DigitalSystems();
            case "German" -> new German();
            case "HardwareBasics" -> new HardwareBasics();
            case "IOTDevelopment" -> new IOTDevelopment();
            case "Mechatronics" -> new Mechatronics();
            case "Microcontrollers" -> new Microcontrollers();
            case "Robotics" -> new Robotics();
            case "English" -> new English();
            case "GS" -> new GS();
            case "OK" -> new OK();
            case "OOP" -> new OOP();
            case "OOP2" -> new OOP2();
            case "PS" -> new PS();
            case "WEBDesign" -> new WEBDesign();
            case "WEBProgramming" -> new WEBProgramming();
            case "Electronics" -> new Electronics();
            case "KSTTechnicalPractice" -> new KSTTechnicalPractice();
            case "AdvancedProgramming" -> new AdvancedProgramming();
            case "SITTechnicalPractice" -> new SITTechnicalPractice();
            case "ProgrammingConsultation" -> new ProgrammingConsultation();
            default -> throw new IllegalArgumentException("Unknown discipline: " + disciplineName);
        };
    }
}
