package commands.logic;

import interfaces.Student;
import specialities.Course;
import specialities.SpecialityKind;
import specialities.kst.FirstCourse;
import specialities.kst.FourthCourse;
import specialities.kst.KST;
import specialities.kst.ThirdCourse;
import specialities.sit.SIT;
import specialities.sit.SecondCourse;
import student.AllStudents;
import student.StudentImpl;
import student.StudentRepository;
import student.discipline.Discipline;
import student.implementation.Group;

import java.util.ArrayList;
import java.util.List;

import static specialities.kst.FirstCourse.KST_DISCIPLINES_1;
import static specialities.kst.FourthCourse.KST_DISCIPLINES_4;
import static specialities.kst.SecondCourse.KST_DISCIPLINES_2;
import static specialities.kst.ThirdCourse.KST_DISCIPLINES_3;
import static specialities.sit.FirstCourse.SIT_DISCIPLINES_1;
import static specialities.sit.FourthCourse.SIT_DISCIPLINES_4;
import static specialities.sit.SecondCourse.SIT_DISCIPLINES_2;
import static specialities.sit.ThirdCourse.SIT_DISCIPLINES_3;

public class Change extends CommandsManager {
    @Override
    public void execute(String command) {
        String[] arr = command.toLowerCase().split(" ");

        if (arr.length < 4) {
            System.out.println("Enter valid number of arguments!");
            return;
        }

        String fn = arr[1];
        String option = arr[2];
        String value = arr[3];

        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }
        if (isGraduated(fn)) {
            System.out.println("Student " + fn + " is graduated.");
            return;
        }

        if(null == findByFakNum(fn)){
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        Student student = findByFakNum(fn);

        switch (option) {
            case "program":
                //enroll 22621624 sit 2b petar
                //change 22621624 program kst
                SpecialityKind speciality;
                if (!studentCanTranfer(student)) {
                    System.out.println("Student " + fn + " can't transfer due not passed exams.");
                    return;
                }
                switch (value) {
                    //student = new StudentImpl(student.getName(), student.getFakNumber(), course,
                    //        speciality, student.getGroup(), student.getStatus());
                    case "sit" -> {
                        String whichCourse = student.getCourse().getClass().getSimpleName();
                        courseSetterSIT(whichCourse, findByFakNum(fn));
                        student.setSpeciality(new SIT());
                    }
                    case "kst" -> {
                        String whichCourse = student.getCourse().getClass().getSimpleName();
                        courseSetterKST(whichCourse, findByFakNum(fn));
                        student.setSpeciality(new KST());
                    }
                    default -> {
                        System.out.println("Invalid program.");
                        return;
                    }
                }
                System.out.println("Program changed to " + value.toUpperCase() + " successfully!");
                break;
            case "group":
                switch (value) {
                    case "1a" -> findByFakNum(fn).setGroup(Group.GROUP1A);
                    case "1b" -> findByFakNum(fn).setGroup(Group.GROUP1B);
                    case "2a" -> findByFakNum(fn).setGroup(Group.GROUP2A);
                    case "2b" -> findByFakNum(fn).setGroup(Group.GROUP2B);
                    case "3a" -> findByFakNum(fn).setGroup(Group.GROUP3A);
                    case "3b" -> findByFakNum(fn).setGroup(Group.GROUP3B);
                    default -> {
                        System.out.println("Invalid group.");
                        return;
                    }
                }
                System.out.println("Group set successfully!");
                break;
            case "year":
                //enroll 22621624 sit 2b petar
                //change 22621624 year secondcourse
                Advance advance = new Advance();

                boolean canBeAdvanced = true;

                List<String> disciplinesWithLowScore = new ArrayList<>();
                for (Discipline d : student.getDisciplines()) {
                    if (d.getEarnedGrade() == 2) {
                        disciplinesWithLowScore.add(d.getName());
                        canBeAdvanced = false;
                    }
                }
                if (!canBeAdvanced) {
                    System.out.println("Student " + student.getFakNumber() + " has not succeeded in "
                            + String.join(", ", disciplinesWithLowScore) + " and can't be advanced.");
                    return;
                }

                String currentCourseSimpleName = student.getCourse().getClass().getSimpleName();
                boolean shouldAdvance;

                switch (value) {
                    case "secondcourse" -> shouldAdvance = currentCourseSimpleName.equals("FirstCourse");
                    case "thirdcourse" -> shouldAdvance = currentCourseSimpleName.equals("SecondCourse");
                    case "fourthcourse" -> shouldAdvance = currentCourseSimpleName.equals("ThirdCourse");
                    default -> {
                        System.out.println("Invalid course.");
                        return;
                    }
                }

                if (shouldAdvance) {
                    advance.execute("advance " + student.getFakNumber());
                } else {
                    System.out.println("You can't change student's course to " + value + ".");
                }
                break;
            default:
                System.out.println("Invalid option parameter.");
        }
    }

    private boolean studentCanTranfer(Student student) {
        int sum = 0;
        for (Discipline d : student.getDisciplines()) {
            if (d.getEarnedGrade() == 2) {
                sum++;
            }
        }
        return sum == 0;
    }

    private void courseSetterKST(String courseName, Student student) {
        switch (courseName){
            case "FirstCourse" -> SIT.studentRepository1.remove(student);
            case "SecondCourse" -> SIT.studentRepository2.remove(student);
            case "ThirdCourse" -> SIT.studentRepository3.remove(student);
            case "FourthCourse" -> SIT.studentRepository4.remove(student);
        }
        Course course = null;
        switch (courseName) {
            case "FirstCourse" -> {
                KST.studentRepository1.add(student);
                course = new specialities.kst.FirstCourse();
            }
            case "SecondCourse" -> {
                KST.studentRepository2.add(student);
                course = new specialities.kst.SecondCourse();
            }
            case "ThirdCourse" -> {
                KST.studentRepository3.add(student);
                course = new specialities.kst.ThirdCourse();
            }
            case "FourthCourse" -> {
                KST.studentRepository4.add(student);
                course = new specialities.kst.FourthCourse();

                /*for (Discipline d : KST_DISCIPLINES_4) {
                    student.addDiscipline(d);
                    setDisciplineGrade(d);
                }*/
            }
        }
        student.setCourse(course);
    }

    private void courseSetterSIT(String courseName, Student student) {
        switch (courseName){
            case "FirstCourse" -> KST.studentRepository1.remove(student);
            case "SecondCourse" -> KST.studentRepository2.remove(student);
            case "ThirdCourse" -> KST.studentRepository3.remove(student);
            case "FourthCourse" -> KST.studentRepository4.remove(student);
        }
        Course course = null;
        switch (courseName) {
            case "FirstCourse" -> {
                SIT.studentRepository1.add(student);
                course = new specialities.sit.FirstCourse();
            }
            case "SecondCourse" -> {
                SIT.studentRepository2.add(student);
                course = new specialities.sit.SecondCourse();
            }
            case "ThirdCourse" -> {
                SIT.studentRepository3.add(student);
                course = new specialities.sit.ThirdCourse();
            }
            case "FourthCourse" -> {
                SIT.studentRepository4.add(student);
                course = new specialities.sit.FourthCourse();
            }
        }
        student.setCourse(course);
    }
}
