package commands.logic;

import interfaces.Student;
import student.discipline.Discipline;

public class Report extends CommandsManager {
    @Override
    public void execute(String command) {
        String[] arr = command.split(" ");
        if (arr.length == 1) {
            System.out.println("Enter a valid number of arguments!");
            return;
        }
        String fn = arr[1];
        if (null == findByFakNum(fn)) {
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        Student student = findByFakNum(fn);
        StringBuilder sb = new StringBuilder();

        boolean hasFailedDisciplines = false;
        sb.append("----------------------------------------\n");
        sb.append("Student ").append(student.getFakNumber()).append(" report:\n");
        for (Discipline d : student.getDisciplines()) {
            if (d.getEarnedGrade() > 2) {
                sb.append(d.getName()).append(" -> ").append(d.getEarnedGrade()).append("\n");
            } else {
                hasFailedDisciplines = true;
            }
        }
        if (hasFailedDisciplines) {
            sb.append("Failed disciplines: \n");
            for (Discipline d : student.getDisciplines()) {
                if (d.getEarnedGrade() == 2 || d.getEarnedGrade() == -1) {
                    sb.append(d.getName()).append(" -> ").append("2").append("\n");
                }
            }
        }
        sb.append("Average score - ").append(String.format("%.2f", student.getAvgScore())).append("\n");
        sb.append("----------------------------------------");
        System.out.println(sb);
    }
}
