package commands.logic;

import interfaces.Student;
import specialities.Course;
import student.AllStudents;
import student.discipline.Discipline;

import java.util.*;
import java.util.stream.Collectors;

public class Protocol extends CommandsManager {
    @Override
    public void execute(String command) {
        String[] arr = command.toLowerCase().split(" ");
        if (arr.length == 1) {
            System.out.println("Enter a valid number of arguments!");
            return;
        }

        Set<Student> studentSetSIT = new HashSet<>();
        Set<Student> studentSetKST = new HashSet<>();
        for (Student s : AllStudents.getAllStudents()) {
            for (Discipline d : s.getDisciplines()) {
                if (d.getName().toLowerCase().equals(arr[1])) {
                    if (s.getSpeciality().getClass().getSimpleName().equals("SIT")) {
                        studentSetSIT.add(s);
                        break;
                    } else if (s.getSpeciality().getClass().getSimpleName().equals("KST")) {
                        studentSetKST.add(s);
                        break;
                    }
                }
            }
        }
        //studentSetSIT.stream().sorted(Comparator.comparing(Student::getFakNumber));
        //studentSetKST.stream().sorted(Comparator.comparing(Student::getFakNumber));

        SortedSet<Student> sortedStudentSetSIT = new TreeSet<>
                (Comparator.comparing(student -> Long.parseLong(student.getFakNumber())));
        sortedStudentSetSIT.addAll(studentSetSIT);

        SortedSet<Student> sortedStudentSetKST = new TreeSet<>
                (Comparator.comparing(student -> Long.parseLong(student.getFakNumber())));
        sortedStudentSetKST.addAll(studentSetKST);


        StringBuilder sb = new StringBuilder();
        sb.append("*******************************\n");
        if (!sortedStudentSetSIT.isEmpty()) {
            sb.append("         SIT STUDENTS\n");
            sb.append("     FIRST COURSE STUDENTS\n");
            for (Student s : sortedStudentSetSIT) {
                if (s.getCourse().getClass().getSimpleName().equals("FirstCourse")) {
                    //sb.append(s);
                    sb.append(s.getName()).append(" ").append(s.getFakNumber())
                            .append(" -> Earned grade: ").append(getDisciplineEarnedGrade(s, arr[1].toLowerCase()));
                    sb.append(System.lineSeparator());
                }
            }
            sb.append("     SECOND COURSE STUDENTS\n");
            for (Student s : sortedStudentSetSIT) {
                if (s.getCourse().getClass().getSimpleName().equals("SecondCourse")) {
                    //sb.append(s);
                    sb.append(s.getName()).append(" ").append(s.getFakNumber())
                            .append(" -> Earned grade: ").append(getDisciplineEarnedGrade(s, arr[1].toLowerCase()));
                    sb.append(System.lineSeparator());
                }
            }
            sb.append("     THIRD COURSE STUDENTS\n");
            for (Student s : sortedStudentSetSIT) {
                if (s.getCourse().getClass().getSimpleName().equals("ThirdCourse")) {
                    //sb.append(s);
                    sb.append(s.getName()).append(" ").append(s.getFakNumber())
                            .append(" -> Earned grade: ").append(getDisciplineEarnedGrade(s, arr[1].toLowerCase()));
                    sb.append(System.lineSeparator());
                }
            }
            sb.append("     FOURTH COURSE STUDENTS\n");
            for (Student s : sortedStudentSetSIT) {
                if (s.getCourse().getClass().getSimpleName().equals("FourthCourse")) {
                    //sb.append(s);
                    sb.append(s.getName()).append(" ").append(s.getFakNumber())
                            .append(" -> Earned grade: ").append(getDisciplineEarnedGrade(s, arr[1].toLowerCase()));
                    sb.append(System.lineSeparator());
                }
            }
            sb.append("*******************************\n");
        }
        if (!sortedStudentSetKST.isEmpty()) {
            sb.append("         KST STUDENTS\n");
            sb.append("     FIRST COURSE STUDENTS\n");
            for (Student s : sortedStudentSetKST) {
                if (s.getCourse().getClass().getSimpleName().equals("FirstCourse")) {
                    //sb.append(s);
                    sb.append(s.getName()).append(" ").append(s.getFakNumber())
                            .append(" -> Earned grade: ").append(getDisciplineEarnedGrade(s, arr[1].toLowerCase()));
                    sb.append(System.lineSeparator());
                }
            }
            sb.append("     SECOND COURSE STUDENTS\n");
            for (Student s : sortedStudentSetKST) {
                if (s.getCourse().getClass().getSimpleName().equals("SecondCourse")) {
                    //sb.append(s);
                    sb.append(s.getName()).append(" ").append(s.getFakNumber())
                            .append(" -> Earned grade: ").append(getDisciplineEarnedGrade(s, arr[1].toLowerCase()));
                    sb.append(System.lineSeparator());
                }
            }
            sb.append("     THIRD COURSE STUDENTS\n");
            for (Student s : sortedStudentSetKST) {
                if (s.getCourse().getClass().getSimpleName().equals("ThirdCourse")) {
                    //sb.append(s);
                    sb.append(s.getName()).append(" ").append(s.getFakNumber())
                            .append(" -> Earned grade: ").append(getDisciplineEarnedGrade(s, arr[1].toLowerCase()));
                    sb.append(System.lineSeparator());
                }
            }
            sb.append("     FOURTH COURSE STUDENTS\n");
            for (Student s : sortedStudentSetKST) {
                if (s.getCourse().getClass().getSimpleName().equals("FourthCourse")) {
                    //sb.append(s);
                    sb.append(s.getName()).append(" ").append(s.getFakNumber())
                            .append(" -> Earned grade: ").append(getDisciplineEarnedGrade(s, arr[1].toLowerCase()));
                    sb.append(System.lineSeparator());
                }
            }
            sb.append("*******************************");
        }
        if (sortedStudentSetKST.isEmpty() && sortedStudentSetSIT.isEmpty()) {
            sb.append("There are no students in this discipline \n" +
                    "or discipline doesn't exist.\n");
            sb.append("*******************************");
        }

        System.out.println(sb);
    }
}
