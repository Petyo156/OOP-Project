package commands.logic;

import interfaces.Student;
import specialities.kst.KST;
import specialities.sit.SIT;
import student.StudentRepository;

public class PrintAll extends CommandsManager {
    @Override
    public void execute(String command) {
        String[] arr = command.toLowerCase().split(" ");
        if (arr.length < 3) {
            System.out.println("Enter valid number of arguments!");
            return;
        }

        String program = arr[1];
        String course = arr[2];

        StudentRepository studentRepository = null;
        switch (program) {
            case "sit" -> {
                switch (course) {
                    case "firstcourse" -> studentRepository = SIT.studentRepository1;
                    case "secondcourse" -> studentRepository = SIT.studentRepository2;
                    case "thirdcourse" -> studentRepository = SIT.studentRepository3;
                    case "fourthcourse" -> studentRepository = SIT.studentRepository4;
                }
            }
            case "kst" -> {
                switch (course) {
                    case "firstcourse" -> studentRepository = KST.studentRepository1;
                    case "secondcourse" -> studentRepository = KST.studentRepository2;
                    case "thirdcourse" -> studentRepository = KST.studentRepository3;
                    case "fourthcourse" -> studentRepository = KST.studentRepository4;
                }
            }
        }

        if (null == studentRepository) {
            System.out.println("Invalid program or course parameter.");
            return;
        }

        System.out.println("-----------------------------------------------------------");
        for (Student student : studentRepository.getCollection()) {
            System.out.println(student);
            System.out.println("-----------------------------------------------------------");
        }

        //enroll 22621624 sit 2b petar
        //enroll 7777 sit 2b ivan
        //enroll 4848 sit 2b kaloqn
    }
}
