package commands.logic;

import interfaces.Student;
import menu.Menu;
import specialities.Course;
import specialities.SpecialityKind;
import student.AllStudents;
import student.discipline.Discipline;
import student.implementation.Group;
import student.implementation.Status;
import student.StudentImpl;
import specialities.kst.KST;
import specialities.sit.SIT;

import java.util.Scanner;

import static specialities.kst.FirstCourse.KST_DISCIPLINES_1;
import static specialities.sit.FirstCourse.SIT_DISCIPLINES_1;

public class Enroll extends CommandsManager {
    @Override
    public void execute(String command) {
        String[] arr = command.split(" ");
        if (arr.length < 5) {
            System.out.println("Enter valid number of arguments!");
            return;
        }

        String name = arr[4];

        arr = command.toLowerCase().split(" ");
        String fn = arr[1];

        if (!fn.matches("\\d+")) {
            System.out.println("FN can't contain characters other than digits.");
            return;
        }

        for (Student s : AllStudents.getAllStudents()) {
            if (s.getFakNumber().equals(fn)) {
                System.out.println("Student with FN " + fn + " already exists!");
                return;
            }
        }


        Group group;
        switch (arr[3]) {
            case "1a" -> group = Group.GROUP1A;
            case "1b" -> group = Group.GROUP1B;
            case "2a" -> group = Group.GROUP2A;
            case "2b" -> group = Group.GROUP2B;
            case "3a" -> group = Group.GROUP3A;
            case "3b" -> group = Group.GROUP3B;
            default -> {
                System.out.println("Invalid group! Failed to add student.");
                return;
            }
        }

        SpecialityKind speciality;
        Course course;
        Student student;
        switch (arr[2]) {
            case "sit" -> {
                speciality = new SIT();
                course = new specialities.sit.FirstCourse();
                student = new StudentImpl(
                        name, fn, course, speciality, group, Status.ENROLLED);
                for (Discipline d : SIT_DISCIPLINES_1) {
                    student.addDiscipline(d);
                    setDisciplineGrade(d);
                }
            }
            case "kst" -> {
                speciality = new KST();
                course = new specialities.kst.FirstCourse();
                student = new StudentImpl(
                        name, fn, course, speciality, group, Status.ENROLLED);
                for (Discipline d : KST_DISCIPLINES_1) {
                    student.addDiscipline(d);
                    setDisciplineGrade(d);
                }
            }
            default -> {
                System.out.println("Invalid speciality! Failed to add student.");
                return;
            }
        }


        switch (arr[2]) {
            case "sit" -> SIT.studentRepository1.add(student);
            case "kst" -> KST.studentRepository1.add(student);
        }

        System.out.println("Student added successfully to FirstCourse!");
    }
}