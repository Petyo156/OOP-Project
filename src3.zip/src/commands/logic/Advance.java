package commands.logic;

import interfaces.Student;
import specialities.Course;
import specialities.kst.FourthCourse;
import specialities.kst.KST;
import specialities.kst.SecondCourse;
import specialities.kst.ThirdCourse;
import specialities.sit.SIT;
import student.StudentImpl;
import student.StudentRepository;
import student.discipline.Discipline;
import student.implementation.Status;

import static specialities.kst.FourthCourse.KST_DISCIPLINES_4;
import static specialities.kst.SecondCourse.KST_DISCIPLINES_2;
import static specialities.kst.ThirdCourse.KST_DISCIPLINES_3;
import static specialities.sit.FirstCourse.SIT_DISCIPLINES_1;
import static specialities.sit.FourthCourse.SIT_DISCIPLINES_4;
import static specialities.sit.SecondCourse.SIT_DISCIPLINES_2;
import static specialities.sit.ThirdCourse.SIT_DISCIPLINES_3;

public class Advance extends CommandsManager {

    @Override
    public void execute(String command) {
        String[] arr = command.split(" ");
        if (arr.length == 1) {
            System.out.println("Enter a valid number of arguments!");
            return;
        }

        String fn = arr[1];

        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }
        if (isGraduated(fn)) {
            System.out.println("Student " + fn + " is graduated.");
            return;
        }

        if(null == findByFakNum(fn)){
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        if(findByFakNum(fn).getCourse().getClass().getSimpleName().equals("FourthCourse")){
            System.out.println("Student is in the last course.");
            return;
        }

        boolean isFound = advanceStudentInSpeciality(SIT.studentRepository1, SIT.studentRepository2, fn);
        isFound = isFound || advanceStudentInSpeciality(SIT.studentRepository2, SIT.studentRepository3, fn);
        isFound = isFound || advanceStudentInSpeciality(SIT.studentRepository3, SIT.studentRepository4, fn);

        isFound = isFound || advanceStudentInSpeciality(KST.studentRepository1, KST.studentRepository2, fn);
        isFound = isFound || advanceStudentInSpeciality(KST.studentRepository2, KST.studentRepository3, fn);
        isFound = isFound || advanceStudentInSpeciality(KST.studentRepository3, KST.studentRepository4, fn);
    }

    private boolean advanceStudentInSpeciality(StudentRepository from, StudentRepository to, String fn) {
        Student student = from.findByFakNum(fn);
        if (student != null) {
            from.remove(student);
            to.add(student);

            Course course = null;
            if (to.equals(SIT.studentRepository2)) {
                course = new specialities.sit.SecondCourse();
                for (Discipline d : SIT_DISCIPLINES_2) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(SIT.studentRepository3)) {
                course = new specialities.sit.ThirdCourse();
                for (Discipline d : SIT_DISCIPLINES_3) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(SIT.studentRepository4)) {
                course = new specialities.sit.FourthCourse();
                for (Discipline d : SIT_DISCIPLINES_4) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(KST.studentRepository2)) {
                course = new specialities.kst.SecondCourse();
                for (Discipline d : KST_DISCIPLINES_2) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(KST.studentRepository3)) {
                course = new specialities.kst.ThirdCourse();
                for (Discipline d : KST_DISCIPLINES_3) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            } else if (to.equals(KST.studentRepository4)) {
                course = new specialities.kst.FourthCourse();
                for (Discipline d : KST_DISCIPLINES_4) {
                    findByFakNum(fn).addDiscipline(d);
                    setDisciplineGrade(d);
                }
            }

            if (course != null) {
                student.setCourse(course);
                System.out.println("Successfully advanced student " + fn + " to " + course.getClass().getSimpleName() + "!");
                return true;
            }
        }
        return false;
    }
}

