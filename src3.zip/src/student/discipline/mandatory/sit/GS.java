package student.discipline.mandatory.sit;

import student.discipline.Discipline;

public class GS extends Discipline {
    public GS() {
        super(-1, -1);
    }
}
