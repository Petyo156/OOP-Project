package student.discipline.mandatory.sit;

import student.discipline.Discipline;

public class PS extends Discipline {
    public PS() {
        super(-1, -1);
    }
}
