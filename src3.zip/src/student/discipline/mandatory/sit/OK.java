package student.discipline.mandatory.sit;

import student.discipline.Discipline;

public class OK extends Discipline {
    public OK() {
        super(-1, -1);
    }
}
