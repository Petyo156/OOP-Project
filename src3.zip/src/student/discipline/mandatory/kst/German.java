package student.discipline.mandatory.kst;

import student.discipline.Discipline;

public class German extends Discipline {
    public German() {
        super(-1, -1);
    }
}
