package student.discipline.mandatory.kst;

import student.discipline.Discipline;

public class IOTDevelopment extends Discipline {
    public IOTDevelopment() {
        super(-1, -1);
    }
}
