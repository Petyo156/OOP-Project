package student.discipline.mandatory.kst;

import student.discipline.Discipline;

public class DigitalSystems extends Discipline {
    public DigitalSystems() {
        super(-1, -1);
    }
}
