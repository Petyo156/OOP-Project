package specialities;

import interfaces.Speciality;
import student.StudentImpl;
import student.StudentRepository;
import student.discipline.Discipline;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public abstract class SpecialityKind extends Course implements Speciality {

    private List<Discipline> disciplines;

    public SpecialityKind() {
        disciplines = new ArrayList<>();
    }

    public void setDisciplines(List<Discipline> disciplines) {
        this.disciplines.addAll(disciplines);
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }
}
