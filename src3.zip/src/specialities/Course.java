package specialities;

import interfaces.Speciality;

public abstract class Course {

}