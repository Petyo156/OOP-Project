package specialities.sit;

import student.discipline.Discipline;
import student.discipline.mandatory.sit.*;

import java.util.List;

public class FourthCourse extends SIT {
    public static final List<Discipline> SIT_DISCIPLINES_4 = List.of(new OOP2(), new WEBProgramming());

    public FourthCourse() {
        super.setDisciplines(SIT_DISCIPLINES_4);
    }
}
