package specialities.sit;

import student.discipline.Discipline;
import student.discipline.mandatory.sit.*;

import java.util.List;

public class ThirdCourse extends SIT{
    public static final List<Discipline> SIT_DISCIPLINES_3 = List.of(new PS(), new GS());

    public ThirdCourse() {
        super.setDisciplines(SIT_DISCIPLINES_3);
    }
}
