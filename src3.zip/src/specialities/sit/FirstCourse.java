package specialities.sit;

import student.discipline.Discipline;
import student.discipline.mandatory.sit.English;
import student.discipline.mandatory.sit.OK;
import student.discipline.mandatory.sit.OOP;
import student.discipline.mandatory.sit.WEBDesign;

import java.util.List;

public class FirstCourse extends SIT {
    public static final List<Discipline> SIT_DISCIPLINES_1 = List.of(new English(), new WEBDesign());

    public FirstCourse() {
        super.setDisciplines(SIT_DISCIPLINES_1);
    }
}
