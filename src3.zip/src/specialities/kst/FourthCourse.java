package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.kst.Microcontrollers;
import student.discipline.mandatory.kst.Robotics;
import student.discipline.mandatory.sit.English;
import student.discipline.mandatory.sit.OK;
import student.discipline.mandatory.sit.OOP;

import java.util.List;

public class FourthCourse extends KST{
    public static final List<Discipline> KST_DISCIPLINES_4 = List.of(new Microcontrollers(), new Robotics());

    public FourthCourse() {
        super.setDisciplines(KST_DISCIPLINES_4);
    }
}
