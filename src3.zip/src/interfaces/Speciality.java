package interfaces;

public interface Speciality {
}
