package student.implementation;

public enum Status {
    ENROLLED, INTERRUPTED, GRADUATED
    /*
        записан - enrolled
        прекъснал - interrupted
        завършил - graduated
     */
}
