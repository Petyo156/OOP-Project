package student.discipline.mandatory;

import student.discipline.Discipline;

public class English extends Discipline {

    public English() {
        super(-1, -1);
    }
}
