package student.discipline.mandatory;

import student.discipline.Discipline;

public class OOP extends Discipline {

    public OOP() {
        super(-1, -1);
    }
}
