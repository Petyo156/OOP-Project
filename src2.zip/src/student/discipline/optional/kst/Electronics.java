package student.discipline.optional.kst;

import student.discipline.Discipline;

public class Electronics extends Discipline {
    public Electronics() {
        super(2, -1);
    }
}
