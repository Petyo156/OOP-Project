package commands.logic;

import interfaces.Speciality;
import interfaces.Student;
import specialities.kst.KST;
import specialities.sit.SIT;
import student.discipline.Discipline;
import student.discipline.optional.kst.Electronics;
import student.discipline.optional.kst.KSTTechnicalPractice;
import student.discipline.optional.sit.AdvancedProgramming;
import student.discipline.optional.sit.SITTechnicalPractice;

public class Enrollin extends CommandsManager {
    @Override
    public void execute(String command) {
        String[] arr = command.toLowerCase().split(" ");
        if (arr.length < 3) {
            System.out.println("Enter valid number of arguments!");
            return;
        }
        String fn = arr[1];

        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }

        if (null == findByFakNum(fn)) {
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        String speciality = findByFakNum(fn).getSpeciality().getClass().getSimpleName();
        String course = arr[2];

        Discipline discipline = null;

        if (speciality.equals("KST")) {
            switch (course) {
                case "electronics" -> discipline = new Electronics();
                case "ksttechnicalpractice" -> discipline = new KSTTechnicalPractice();
                default -> {
                    System.out.println("Discipline is not a KST discipline.");
                    return;
                }
            }
        } else if (speciality.equals("SIT")) {
            switch (course) {
                case "advancedprogramming" -> discipline = new AdvancedProgramming();
                case "sittechnicalpractice" -> discipline = new SITTechnicalPractice();
                default -> {
                    System.out.println("Discipline is not a SIT discipline.");
                    return;
                }
            }
        }

        for (Discipline d : findByFakNum(fn).getDisciplines()) {
            if (d.getName().equals(discipline.getClass().getSimpleName())) {
                System.out.println("Student already has the discipline enrolled.");
                return;
            }
        }

        int courseInt = switch (findByFakNum(fn).getCourse().getClass().getSimpleName()) {
            case "FirstCourse" -> 1;
            case "SecondCourse" -> 2;
            case "ThirdCourse" -> 3;
            case "FourthCourse" -> 4;
            default -> 0;
        };

        if (courseInt >= discipline.getCourseNeeded()) {
            findByFakNum(fn).addDiscipline(discipline);
            System.out.println("Successfully added discipline!");
        } else {
            System.out.println("Student is not quite there yet.");
        }

        //enroll 22621624 sit 2b petar
        //enrollin 22621624 AdvancedProgramming

        //enroll 22621624 kst 2b petar
        //enrollin 22621624 Electronics
    }
}
