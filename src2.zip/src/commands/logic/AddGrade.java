package commands.logic;

import interfaces.Student;
import student.discipline.Discipline;

import java.util.Scanner;

public class AddGrade extends CommandsManager {
    @Override
    public void execute(String command) {
        String[] arr = command.toLowerCase().split(" ");
        if (arr.length < 4) {
            System.out.println("Enter a valid number of arguments!");
            return;
        }

        String fn = arr[1];

        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }

        if (null == findByFakNum(fn)) {
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        String course = arr[2];
        int grade = -1;
        try {
            grade = Integer.parseInt(arr[3]);
            if (grade < 2 || grade > 6) {
                throw new IllegalArgumentException();
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Grade can only be a number between 2-6.");
            return;
        }

        for (Discipline d : findByFakNum(fn).getDisciplines()) {
            if(d.getName().toLowerCase().equals(course)){
                d.setEarnedGrade(grade);
                System.out.println("Grade set successfully!");
                return;
            }
        }

        System.out.println("Discipline is not included in current student disciplines.");
    }

}
