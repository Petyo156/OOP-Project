package commands.logic;

import interfaces.Student;
import student.discipline.Discipline;
import student.implementation.Status;

import java.util.ArrayList;
import java.util.List;

public class Graduate extends CommandsManager{
    @Override
    public void execute(String command) {
        String[] arr = command.split(" ");
        if(arr.length == 1){
            System.out.println("Enter valid number of arguments!");
            return;
        }
        String fn = arr[1];

        if (isInterrupted(fn)) {
            System.out.println("Student " + fn + " is interrupted.");
            return;
        }

        if(null == findByFakNum(fn)){
            System.out.println("Student " + fn + " doesn't exist!");
            return;
        }

        if(checkIfGoodScore(findByFakNum(fn))){
            findByFakNum(fn).setStatus(Status.GRADUATED);
            System.out.println("Student graduated successfully!");
        }
    }
}
