package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.English;
import student.discipline.mandatory.OK;
import student.discipline.mandatory.OOP;

import java.util.List;

public class ThirdCourse extends KST{
    public static final List<Discipline> KST_DISCIPLINES_3 = List.of(new English(), new OK(), new OOP());

    public ThirdCourse() {
        super.setDisciplines(KST_DISCIPLINES_3);
    }
}
