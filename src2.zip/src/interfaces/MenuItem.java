package interfaces;

public interface MenuItem {
    void execute();
    void execute(String command);
}
