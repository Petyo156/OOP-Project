package student.discipline.optional;

import student.discipline.Discipline;

public class TechnicalPractice extends Discipline {
    public TechnicalPractice() {
        super(3, -1);
    }
}
