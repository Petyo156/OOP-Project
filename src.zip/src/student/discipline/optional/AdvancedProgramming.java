package student.discipline.optional;

import student.discipline.Discipline;

public class AdvancedProgramming extends Discipline {
    public AdvancedProgramming() {
        super(2, -1);
    }
}
