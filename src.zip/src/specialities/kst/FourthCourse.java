package specialities.kst;

import student.discipline.Discipline;
import student.discipline.mandatory.English;
import student.discipline.mandatory.OK;
import student.discipline.mandatory.OOP;

import java.util.List;

public class FourthCourse extends KST{
    public static final List<Discipline> KST_DISCIPLINES_4 = List.of(new English(), new OK(), new OOP());

    public FourthCourse() {
        super.setDisciplines(KST_DISCIPLINES_4);
        setGrades();
    }
}
