package specialities;

import interfaces.Speciality;

public abstract class Course {
    //za vsqka specialnost vseki kurs ima razlichni predmeti
}